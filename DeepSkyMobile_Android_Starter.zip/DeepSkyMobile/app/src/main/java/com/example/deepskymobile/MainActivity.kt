package com.example.deepskymobile

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.*
import android.graphics.Color
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.media.ImageReader
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.Size
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var preview: SurfaceView
    private lateinit var holder: SurfaceHolder
    private lateinit var cameraManager: CameraManager
    private var cameraId: String = ""
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var iso = 1600
    private var exposureNs = 5_000_000_000L
    private var focusDistance = 0f
    private var maxIso = 3200
    private var minIso = 100
    private var maxExposure = 10_000_000_000L
    private var minFocus = 0f
    private var maxFocus = 0f
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,12,22)
        window.navigationBarColor = Color.rgb(8,12,22)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        thread = HandlerThread("DeepSkyCamera").also { it.start() }
        handler = Handler(thread!!.looper)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.CAMERA), 100)
        else openCameraWhenReady()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8,12,22)); setPadding(18,18,18,18) }
        val title = TextView(this).apply { text = "DEEPSKY MOBILE  ·  ASTRO"; textSize=18f; setTextColor(Color.WHITE); setPadding(0,8,0,16) }
        root.addView(title)
        preview = SurfaceView(this).apply { setBackgroundColor(Color.BLACK) }
        holder = preview.holder; holder.addCallback(this)
        root.addView(preview, LinearLayout.LayoutParams(-1,0,1f))
        status = TextView(this).apply { text="Manual capture"; textColor=Color.LTGRAY; textSize=13f; setPadding(0,12,0,8) }; root.addView(status)
        root.addView(label("ISO  ·  Adjust sensitivity"))
        val isoBar = SeekBar(this).apply { max=3200; progress=iso; setOnSeekBarChangeListener(simpleSeek { v -> iso=(v.coerceAtLeast(100)); status.text="ISO $iso" }) }; root.addView(isoBar)
        root.addView(label("EXPOSURE  ·  1–10 seconds"))
        val expBar = SeekBar(this).apply { max=100; progress=50; setOnSeekBarChangeListener(simpleSeek { v -> exposureNs=(1_000_000_000L + v.coerceAtLeast(0)*90_000_000L); status.text="Exposure ${(exposureNs/1_000_000_000.0).toString().take(4)} s" }) }; root.addView(expBar)
        root.addView(label("FOCUS  ·  0 = infinity"))
        val focusBar = SeekBar(this).apply { max=100; progress=0; setOnSeekBarChangeListener(simpleSeek { v -> focusDistance=maxFocus*(v/100f); status.text="Focus manual"; applyPreview() }) }; root.addView(focusBar)
        val capture = Button(this).apply { text="CAPTURE LONG EXPOSURE"; setTextColor(Color.BLACK); setBackgroundColor(Color.rgb(125,211,252)); setOnClickListener { capturePhoto() } }
        root.addView(capture, LinearLayout.LayoutParams(-1,-2))
        setContentView(root)
    }
    private fun label(s:String)=TextView(this).apply { text=s; textColor=Color.rgb(170,190,215); textSize=12f; setPadding(0,8,0,2) }
    private fun simpleSeek(fn:(Int)->Unit)=object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,v:Int,u:Boolean)=fn(v); override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} }

    private fun openCameraWhenReady() { if(holder.surface.isValid) openCamera() }
    override fun surfaceCreated(h: SurfaceHolder) { if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) openCamera() }
    override fun surfaceChanged(h:SurfaceHolder, f:Int,w:Int,he:Int) { }
    override fun surfaceDestroyed(h:SurfaceHolder) { session?.close(); session=null; device?.close(); device=null }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, results:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,results); if(requestCode==100 && results.isNotEmpty() && results[0]==PackageManager.PERMISSION_GRANTED) openCameraWhenReady() else status.text="Camera permission required" }

    private fun openCamera() {
        try {
            cameraId=cameraManager.cameraIdList.firstOrNull { id -> cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)==CameraCharacteristics.LENS_FACING_BACK } ?: cameraManager.cameraIdList.first()
            val chars=cameraManager.getCameraCharacteristics(cameraId)
            chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { minIso=it.lower; maxIso=it.upper }
            chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { maxExposure=it.upper.coerceAtMost(10_000_000_000L) }
            chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)?.let { maxFocus=it }
            cameraManager.openCamera(cameraId, object:CameraDevice.StateCallback(){ override fun onOpened(c:CameraDevice){ device=c; startPreview() }; override fun onDisconnected(c:CameraDevice){ c.close() }; override fun onError(c:CameraDevice,e:Int){ status.text="Camera error: $e" } },handler)
        } catch(e:Exception){ status.text="Unable to open camera: ${e.message}" }
    }
    private fun startPreview() {
        val d=device ?: return; if(!holder.surface.isValid)return
        try {
            val map=d.getCameraCharacteristics(cameraId).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val size=map?.getOutputSizes(android.graphics.ImageFormat.JPEG)?.maxByOrNull { it.width.toLong()*it.height } ?: Size(1920,1080)
            reader=ImageReader.newInstance(size.width,size.height,android.graphics.ImageFormat.JPEG,2)
            d.createCaptureSession(listOf(holder.surface,reader!!.surface), object:CameraCaptureSession.StateCallback(){ override fun onConfigured(s:CameraCaptureSession){ session=s; applyPreview() }; override fun onConfigureFailed(s:CameraCaptureSession){ status.text="Preview configuration failed" } },handler)
        } catch(e:Exception){ status.text=e.message ?: "Preview failed" }
    }
    private fun applyPreview(){ try { val d=device ?: return; val s=session ?: return; val req=d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(holder.surface); set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO); if(maxFocus>0) { set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_OFF); set(CaptureRequest.LENS_FOCUS_DISTANCE,focusDistance) } }; s.setRepeatingRequest(req.build(),null,handler) } catch(_:Exception){} }
    private fun capturePhoto() {
        val d=device ?: return; status.text="Capturing…"
        try {
            reader!!.setOnImageAvailableListener({ r ->
                val img=r.acquireNextImage() ?: return@setOnImageAvailableListener
                val bytes=img.planes[0].buffer.let { b -> ByteArray(b.remaining()).also(b::get) }; img.close()
                saveJpeg(bytes); r.close()
            },handler)
            val req=d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(reader!!.surface); set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_OFF)
                set(CaptureRequest.SENSOR_SENSITIVITY,iso.coerceIn(minIso,maxIso)); set(CaptureRequest.SENSOR_EXPOSURE_TIME,exposureNs.coerceAtMost(maxExposure).coerceAtLeast(1_000_000L)); set(CaptureRequest.SENSOR_FRAME_DURATION,exposureNs.coerceAtMost(maxExposure));
                if(maxFocus>0){ set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_OFF); set(CaptureRequest.LENS_FOCUS_DISTANCE,focusDistance) }
            }
            session?.capture(req.build(),object:CameraCaptureSession.CaptureCallback(){ override fun onCaptureCompleted(s:CameraCaptureSession,r:CaptureRequest,result:TotalCaptureResult){ runOnUiThread { status.text="Exposure captured · saving"; applyPreview() } } },handler)
        } catch(e:Exception){ status.text="Capture failed: ${e.message}" }
    }
    private fun saveJpeg(bytes:ByteArray) { try { val dir=getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir; val f=File(dir,"DeepSky_${SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())}.jpg"); FileOutputStream(f).use{it.write(bytes)}; runOnUiThread{status.text="Saved: ${f.name}"}; MediaScannerConnection.scanFile(this,arrayOf(f.absolutePath),arrayOf("image/jpeg"),null) } catch(e:Exception){runOnUiThread{status.text="Save failed"}} }
    override fun onDestroy(){ session?.close(); device?.close(); reader?.close(); thread?.quitSafely(); super.onDestroy() }
}
