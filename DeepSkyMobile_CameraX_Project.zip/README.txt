DeepSky Mobile CameraX starter (version 0.5)

This package contains a complete Android Gradle project in the DeepSkyMobile/ folder.

Features in this initial camera-focused version:
- CameraX live preview using PreviewView
- Back/front camera switching
- Tap-to-focus and metering
- Exposure compensation (EV) control, when supported by the device
- Flash toggle, when supported by the device
- JPEG photo capture saved to Pictures/DeepSkyMobile
- LIGHTS / DARKS / FLATS / BIAS filename labels
- Layout inspired by the supplied DeepSky Camera screenshot

Not implemented in this initial version:
- DNG/RAW capture
- Manual sensor ISO control
- Multi-second manual shutter / long-exposure astrophotography
- Stacking, dark-frame subtraction, and astronomical image processing

Build requirements used by the accompanying GitHub Actions workflow:
- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.11.1
- Kotlin Gradle Plugin 2.2.21
- Android compile SDK 36
- CameraX 1.7.0
