package com.example.deepskymobile

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var statusView: TextView
    private lateinit var exposureValueView: TextView
    private lateinit var typeValueView: TextView
    private lateinit var flashValueView: TextView
    private lateinit var thumbnailView: ImageView
    private lateinit var photoCountView: TextView

    private val mainExecutor = Executor { command -> runOnUiThread(command) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var bindingCamera = false
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var latestPhotoUri: Uri? = null
    private var selectedType = 0
    private val captureTypes = listOf("LIGHTS", "DARKS", "FLATS", "BIAS")
    private var exposureIndex = 0
    private var flashEnabled = false
    private var showStatus = true
    private var photoCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.navigationBarColor = Color.rgb(8, 10, 18)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        buildCameraScreen()

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            previewView.post { startCamera() }
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
        }
    }

    private fun buildCameraScreen() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            setBackgroundColor(Color.BLACK)
        }
        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                focusAt(event.x, event.y)
                true
            } else {
                true
            }
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(18), dp(14), dp(14))
            setBackgroundColor(0x99000000.toInt())
        }

        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleColumn.addView(text("DEEPSKY", 25f, Color.WHITE, true))
        val subtitle = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        subtitle.addView(text("CAMERA", 21f, Color.WHITE, false))
        subtitle.addView(text("  FREE", 11f, 0xFFB7C2CC.toInt(), true).apply {
            setPadding(0, 0, 0, dp(3))
        })
        titleColumn.addView(subtitle)
        topBar.addView(
            titleColumn,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        val eyeButton = text("◎", 31f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            setOnClickListener {
                showStatus = !showStatus
                statusView.visibility = if (showStatus) View.VISIBLE else View.GONE
            }
        }
        topBar.addView(eyeButton)

        val menuButton = text("⋮", 32f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { showMenu(this) }
        }
        topBar.addView(menuButton)

        root.addView(
            topBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        statusView = text("OPENING CAMERA…", 12f, Color.WHITE, true).apply {
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = rounded(0x99000000.toInt(), 24f)
            gravity = Gravity.CENTER
        }
        val statusHolder = FrameLayout(this).apply {
            addView(
                statusView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }
        root.addView(
            statusHolder,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48),
                Gravity.TOP
            ).apply { topMargin = dp(104) }
        )

        val bottomPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xB8000000.toInt())
        }

        val controlsScroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        val controlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val filesChip = makeChip("▱", "JPG", 0xFF252831.toInt())
        filesChip.setOnClickListener { openLatestPhoto() }
        controlsRow.addView(filesChip, chipParams())

        val typeChip = makeChip("TYPE", captureTypes[selectedType], 0xFF30323A.toInt())
        typeValueView = typeChip.getChildAt(1) as TextView
        typeChip.setOnClickListener {
            selectedType = (selectedType + 1) % captureTypes.size
            typeValueView.text = captureTypes[selectedType]
        }
        controlsRow.addView(typeChip, chipParams())

        val exposureChip = makeChip("☼", "EV 0.0", 0xFF30323A.toInt())
        exposureValueView = exposureChip.getChildAt(1) as TextView
        exposureChip.setOnClickListener { adjustExposure() }
        controlsRow.addView(exposureChip, chipParams())

        val isoChip = makeChip("ISO", "AUTO", 0xFF30323A.toInt())
        isoChip.setOnClickListener {
            Toast.makeText(
                this,
                "ISO manual belum aktif. Kamera memakai pengaturan otomatis pada versi ini.",
                Toast.LENGTH_LONG
            ).show()
        }
        controlsRow.addView(isoChip, chipParams())

        val flashChip = makeChip("⚡", "OFF", 0xFF30323A.toInt())
        flashValueView = flashChip.getChildAt(1) as TextView
        flashChip.setOnClickListener {
            flashEnabled = !flashEnabled
            flashValueView.text = if (flashEnabled) "ON" else "OFF"
            imageCapture?.flashMode = if (flashEnabled) {
                ImageCapture.FLASH_MODE_ON
            } else {
                ImageCapture.FLASH_MODE_OFF
            }
        }
        controlsRow.addView(flashChip, chipParams())

        controlsScroller.addView(controlsRow)
        bottomPanel.addView(
            controlsScroller,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(98)
            )
        )

        val captureRow = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(112)
            )
        }

        photoCountView = text("$photoCount PHOTOS", 10f, 0xFFCAD0D8.toInt(), true).apply {
            gravity = Gravity.CENTER
        }
        captureRow.addView(
            photoCountView,
            FrameLayout.LayoutParams(dp(90), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        )

        val shutterOuter = FrameLayout(this).apply {
            background = rounded(Color.TRANSPARENT, 60f, Color.WHITE, 5f)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setOnClickListener { capturePhoto() }
        }
        val shutterInner = View(this).apply {
            background = rounded(0xFF080A14.toInt(), 50f, 0xFFE5E7EB.toInt(), 1f)
            isClickable = false
        }
        shutterOuter.addView(
            shutterInner,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        captureRow.addView(
            shutterOuter,
            FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER)
        )

        thumbnailView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(0xFF252831.toInt(), 10f, 0xFF777777.toInt(), 1f)
            setOnClickListener { openLatestPhoto() }
        }
        captureRow.addView(
            thumbnailView,
            FrameLayout.LayoutParams(dp(76), dp(62), Gravity.END or Gravity.CENTER_VERTICAL)
        )

        bottomPanel.addView(captureRow)
        root.addView(
            bottomPanel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        setContentView(root)
    }

    private fun makeChip(top: String, bottom: String, color: Int): LinearLayout {
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(color, 48f)
        }
        chip.addView(text(top, 19f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
        })
        chip.addView(text(bottom, 10f, 0xFFD7DCE3.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        })
        return chip
    }

    private fun chipParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(dp(88), dp(88)).apply {
            marginEnd = dp(12)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = true
        }

    private fun rounded(
        color: Int,
        radius: Float,
        strokeColor: Int? = null,
        strokeWidth: Float = 0f
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius.toInt()).toFloat()
        if (strokeColor != null && strokeWidth > 0f) {
            setStroke(dp(strokeWidth.toInt()), strokeColor)
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add("Switch camera")
        menu.menu.add(if (flashEnabled) "Turn flash off" else "Turn flash on")
        menu.menu.add("Reset exposure")
        menu.menu.add("About DeepSky Mobile")
        menu.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Switch camera" -> switchCamera()
                "Turn flash off", "Turn flash on" -> {
                    flashEnabled = !flashEnabled
                    flashValueView.text = if (flashEnabled) "ON" else "OFF"
                    imageCapture?.flashMode = if (flashEnabled) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                }
                "Reset exposure" -> {
                    exposureIndex = 0
                    camera?.cameraControl?.setExposureCompensationIndex(0)
                    updateExposureLabel()
                }
                "About DeepSky Mobile" -> Toast.makeText(
                    this,
                    "DeepSky Mobile 0.5 · CameraX preview and JPEG capture",
                    Toast.LENGTH_LONG
                ).show()
            }
            true
        }
        menu.show()
    }

    private fun startCamera() {
        if (bindingCamera || camera != null) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

        bindingCamera = true
        statusView.text = "CONNECTING CAMERA…"

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(95)
                    .build()

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, capture)
                imageCapture = capture
                camera?.cameraControl?.setExposureCompensationIndex(0)
                exposureIndex = 0
                updateExposureLabel()
                statusView.text = "LIVE VIEW  ·  TAP TO FOCUS"

            } catch (error: Exception) {
                camera = null
                imageCapture = null
                statusView.text = "CAMERA ERROR · ${error.javaClass.simpleName}"
                Toast.makeText(
                    this,
                    "Kamera gagal dibuka: ${error.message ?: "Unknown error"}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                bindingCamera = false
            }
        }, mainExecutor)
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        cameraProvider?.unbindAll()
        camera = null
        imageCapture = null
        startCamera()
    }

    private fun focusAt(x: Float, y: Float) {
        val activeCamera = camera ?: return
        try {
            val point = previewView.meteringPointFactory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(point)
                .setAutoCancelDuration(3, TimeUnit.SECONDS)
                .build()
            activeCamera.cameraControl.startFocusAndMetering(action)
            statusView.text = "FOCUSING…"
        } catch (_: Exception) {
            statusView.text = "TAP TO FOCUS"
        }
    }

    private fun adjustExposure() {
        val activeCamera = camera ?: return
        val state = activeCamera.cameraInfo.exposureState
        val range = state.exposureCompensationRange
        if (range.isEmpty()) {
            Toast.makeText(this, "Exposure compensation tidak didukung kamera ini.", Toast.LENGTH_SHORT).show()
            return
        }

        exposureIndex = if (exposureIndex >= range.upper) range.lower else exposureIndex + 1
        activeCamera.cameraControl.setExposureCompensationIndex(exposureIndex)
        updateExposureLabel()
    }

    private fun updateExposureLabel() {
        if (!::exposureValueView.isInitialized) return
        val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 1f
        val ev = exposureIndex * step
        exposureValueView.text = String.format(Locale.US, "EV %+.1f", ev)
    }

    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            Toast.makeText(this, "Kamera belum siap.", Toast.LENGTH_SHORT).show()
            return
        }

        capture.flashMode = if (flashEnabled) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "DeepSky_${captureTypes[selectedType]}_${timestamp}.jpg"
        val outputOptions: ImageCapture.OutputFileOptions
        var fallbackFile: File? = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_PICTURES}/DeepSkyMobile"
                )
            }
            outputOptions = ImageCapture.OutputFileOptions.Builder(
                contentResolver,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            ).build()
        } else {
            val directory = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
            fallbackFile = File(directory, fileName)
            outputOptions = ImageCapture.OutputFileOptions.Builder(fallbackFile).build()
        }

        statusView.text = "CAPTURING…"
        capture.takePicture(
            outputOptions,
            mainExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val savedUri = output.savedUri ?: fallbackFile?.let { Uri.fromFile(it) }
                    latestPhotoUri = savedUri
                    if (savedUri != null) thumbnailView.setImageURI(savedUri)
                    photoCount += 1
                    photoCountView.text = "$photoCount PHOTOS"
                    statusView.text = "PHOTO SAVED  ·  $fileName"
                }

                override fun onError(exception: ImageCaptureException) {
                    statusView.text = "SAVE ERROR"
                    Toast.makeText(
                        this@MainActivity,
                        "Foto gagal disimpan: ${exception.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }

    private fun openLatestPhoto() {
        val uri = latestPhotoUri
        if (uri == null) {
            Toast.makeText(this, "Belum ada foto yang diambil.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "image/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak ada aplikasi galeri yang tersedia.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                previewView.post { startCamera() }
            } else {
                statusView.text = "CAMERA PERMISSION REQUIRED"
                Toast.makeText(this, "Izinkan akses kamera untuk menggunakan DeepSky Mobile.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::previewView.isInitialized &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) {
            previewView.post { startCamera() }
        }
    }

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        camera = null
        imageCapture = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_CAMERA = 100
    }
}
